# FBT for python2 and python3

To run the example, please execute the following commands

python example.py

Author:
John Terry, johndterry@physics.ucla.edu
