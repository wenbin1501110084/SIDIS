# FBT for Fortran 77

To run the example, please execute the following commands

make
./example.out
python plot.py

Author:
John Terry, johndterry@physics.ucla.edu
