/*
20-2-19 Testing C++ wrapper for DSS FORTRAN package.
*/
#include <stdio.h>
#include <math.h>
#include <iterator>
#include <stdlib.h>
#include <cstdlib>
#include <iostream>
using namespace std;


extern "C"
{
double fdss_(int *is, int *ih, int *ic, int *io, double *x, double *Q2, double *u, double *ub, double *d, double *db, double *s, double *sb, double *c, double *b, double *gl);
}


int main()
{
cout<<"Testing C++ wrapper for DSS FF package\n";
int is=1, ih=1, ic=0, io=0;
double Q2=100.0, z=0.1;
double u, ub, d, db, s, sb, c, b, gl;

fdss_(&is, &ih, &ic, &io, &z, &Q2, &u, &ub, &d, &db, &s, &sb, &c, &b, &gl);

cout<<"u = "<<u/z<<", ub = "<<ub/z<<", d = "<<d/z<<", db = "<<db/z<<"\n";

return 0;
}
